package com.example.chrisparkseventtrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class AddEventActivity extends AppCompatActivity {

    CalendarView calendar;
    Button cancelButton;
    Button saveButton;
    EditText nameEdit;
    EditText timeEdit;
    EditText descripEdit;
    EventsDatabase eventsDatabase;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_event);
        cancelButton = (Button) findViewById(R.id.cancelButton);
        saveButton = (Button) findViewById(R.id.saveButton);
        nameEdit = (EditText) findViewById(R.id.nameEdit);
        timeEdit = (EditText) findViewById(R.id.timeEdit);
        descripEdit = (EditText) findViewById(R.id.descripEdit);
        eventsDatabase = new EventsDatabase(AddEventActivity.this);
        calendar = findViewById(R.id.calender);
        calendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                String Date = dayOfMonth + "-" + (month + 1) + "-" + year;
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AddEventActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameEdit.getText().toString();
                long date = calendar.getDate();
                String time = timeEdit.getText().toString();
                String description = descripEdit.getText().toString();

                long addEvents = eventsDatabase.addEvent(name, date, time, description);

                if(addEvents > 0) {
                    Toast.makeText(AddEventActivity.this, "Event Added", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(AddEventActivity.this, MainActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(AddEventActivity.this, "Event not add.  Please try again.", Toast.LENGTH_SHORT).show();
                }

            }
        });


    }
}
