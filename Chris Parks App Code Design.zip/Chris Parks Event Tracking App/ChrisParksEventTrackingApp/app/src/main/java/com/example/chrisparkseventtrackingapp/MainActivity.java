package com.example.chrisparkseventtrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {


    Button addButton;
    private ListView EventsList;
    EventsDatabase eventsDatabase;
    TextView nameText;
    TextView dateDisp;
    TextView timeDisp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addButton = (Button) findViewById(R.id.addButton);
        nameText = (TextView) findViewById(R.id.nameText);
        dateDisp = (TextView) findViewById(R.id.dateDisp);
        timeDisp = (TextView) findViewById(R.id.timeDisp);
        eventsDatabase = new EventsDatabase(MainActivity.this);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddEventActivity.class);
                startActivity(intent);
            }
        });

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.appbar_menu, menu);
        return true;

    }

    @Override
    protected void onResume()
    {
        super.onResume();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;

        switch (item.getItemId()) {
            case R.id.action_settings:
                // Settings selected
                intent = new Intent(MainActivity.this, SettingsActivity.class);
                startActivity(intent);
                return true;

            case R.id.action_about:
                // About selected
                intent = new Intent(MainActivity.this, AboutActivity.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void displayData() {
      // This still needs to get resolved

        // getData = eventsDatabase.getEvents();

      // nameText.setText(getData.nameText);
      // dateDisp.setText(getData.date);
      // timeDisp.setText(getData.timeText);
    }


}

